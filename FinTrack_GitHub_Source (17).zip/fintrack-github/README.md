# FinTrack – Personal Finance Management

A responsive personal-finance dashboard built with HTML, CSS and JavaScript.

## Features
- Demo sign-in and account creation
- Dashboard with balance, income, expenses and savings rate
- Add, search, filter and delete transactions
- Category-wise expense chart
- Monthly category budgets with progress indicators
- Recurring transaction list
- Export transactions to CSV
- Responsive layout for desktop and mobile

## Run locally
1. Download or clone this repository.
2. Open the folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the VS Code Live Server extension.
4. Data is saved in the browser's `localStorage`.

## Publish on GitHub
1. Create a new repository on GitHub.
2. Upload `index.html`, the `css` folder, the `js` folder and this README.
3. Commit the files.
4. To publish it as a website, open **Settings → Pages**, choose the `main` branch and `/ (root)`, then save.

## Important limitations
This is a frontend demonstration. It stores demo account details and finance records in browser `localStorage`; it does not provide secure authentication, cloud sync, a database, or multi-user access. Do not enter real passwords or sensitive financial information. For a production application, connect a secure backend, database, and proper authentication.
